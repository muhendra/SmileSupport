﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page {
	protected void Page_Load(object sender, EventArgs e) {

	}
	protected void UploadControl_FileUploadComplete(object sender, DevExpress.Web.FileUploadCompleteEventArgs e) {
		AddImage(e.UploadedFile.FileName, e.UploadedFile.FileBytes);
	}
	void AddImage(string Name, byte[] content) {
		var connString = ConfigurationManager.ConnectionStrings["NWindConnectionString"].ConnectionString;

		using(SqlConnection conn = new SqlConnection(connString)) {
			conn.Open();
			var command = "INSERT INTO Categories (CategoryName, Picture) VALUES ('" + Name + "', @Content)";
			SqlCommand cmd = new SqlCommand(command, conn);
			SqlParameter param = cmd.Parameters.Add("@Content", SqlDbType.Image);
			param.Value = content;
			cmd.ExecuteNonQuery();
		}
	}
	protected void callbackPanel_Callback(object sender, DevExpress.Web.CallbackEventArgsBase e) {
		imageSlider.DataBind();
	}
}